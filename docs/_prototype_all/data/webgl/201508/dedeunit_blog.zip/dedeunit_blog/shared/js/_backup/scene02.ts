/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />

class scene02
{
	public scene:any;

	private camera:any;
	private container:any;

	private accell:number;
	private accellTarget:number;

	constructor( _camera )
	{
		console.log( 'scene ' + '%cscene02',  'color: #990000;font: bold 12px sans-serif;' );

		var _t = this;
		_t.scene = new THREE.Scene();
		_t.scene.fog = new THREE.Fog( 0x000000, 800, 1600 );

		_t.container = new THREE.Group();
		_t.scene.add( _t.container );

		_t.camera = _camera;

		_t.accell = 0;
		_t.accellTarget = 0;

		var _size = 10;
		//	astroid
		for( var i = 0; i < 512; i++ )
		{
			var _x = Math.floor( rnd() * 16 ) * 32;
			var _y = Math.floor( rnd() * 16 ) * 32;
			var _z = Math.floor( rnd() * 16 ) * 32;

			var _c = new THREE.Vector3( _x,_y,_z );
			_c.normalize();
			_c.x = ( _c.x + 1 ) / 2;
			_c.y = ( _c.y + 1 ) / 2;
			_c.z = ( _c.z + 1 ) / 2;
			var _color:any = new THREE.Color( _c.x, _c.y, _c.z );

			var _geometry = new THREE.BoxGeometry( _size,_size,_size,1,1,1 );
			var _material = new THREE.MeshBasicMaterial({'color':_color});
			var _mesh = new THREE.Mesh( _geometry, _material );

			_mesh.position.set(_x,_y,_z);

			var _scale = Math.floor( Math.random() * 5 + 1 );
			_mesh.scale.set(_scale,_scale,_scale);

			_mesh.rotation.set(rnd()*Math.PI,rnd()*Math.PI,rnd()*Math.PI);
			_mesh.rotationVector = new THREE.Vector3(rnd()*Math.PI*0.02,rnd()*Math.PI*0.02,rnd()*Math.PI*0.02);
			_mesh.max = Math.sqrt( _mesh.position.x*_mesh.position.x + _mesh.position.y*_mesh.position.y + _mesh.position.z*_mesh.position.z );

			_t.container.add( _mesh );
		}

		//	+-1.0
		function rnd()
		{
			return Math.random()*2-1;
		}
	}

	public update()
	{
		var _t = this;
		//_t.container.rotation.x += 0.01;
		//_t.container.rotation.y += 0.01;


		_t.accell += ( _t.accellTarget - _t.accell ) * 0.05;


		_t.accell = ( Math.sin( Date.now() * 0.001 ) + 1.0 ) * 0.5 + 0.245;

		var len = _t.container.children.length;
		while( len )
		{
			len --;
			var _mesh = _t.container.children[len];

			if( !_mesh ){	continue;	}

			var _dx = _mesh.position.x;
			var _dy = _mesh.position.y;
			var _dz = _mesh.position.z;
			//var _dist = Math.sqrt( _dx*_dx + _dy*_dy + _dz*_dz);
			var _rad = ( _t.accell / ( len*0.25 + 10 ) );
			var _sin = Math.sin( _rad );
			var _cos = Math.cos( _rad );
			var __dx = _cos * _dx - _sin * _dz;
			var __dz = _sin * _dx + _cos * _dz;

			_mesh.position.x = __dx;
			_mesh.position.z = __dz;





			var _par = _rad / ( Math.PI * 0.25 );

			_mesh.rotation.x += _mesh.rotationVector.x * _t.accell;
			_mesh.rotation.y += _mesh.rotationVector.y * _t.accell;
			_mesh.rotation.z += _mesh.rotationVector.z * _t.accell;

		}

		_t.accellTarget *= 0.99;
	}

	public interactive( _type, _data )
	{
		var _t = this;
		if( _type == 'kinect' )
		{
			var _isLeft = _data.gestureData.IsHandUpLeft;
			var _isRight = _data.gestureData.IsHandUpRight;
		} else if( _type == 'accell' )
		{
			_t.accellTarget += _data.x;

			//var PI = Math.PI;
			//_t.accellTarget = _t.accellTarget<-PI?-PI:_t.accellTarget>PI?PI:_t.accellTarget;
		} 
	}
	
	public dispose()
	{
		var _t = this;
		kill( _t.scene );

		function kill( e )
		{
			var len = e.children.length;
			while( len )
			{
				len --;
				var _target = e.children[len];
				
				//	再起kill
				if( _target.length )
				{
					kill( _target );
				}

				//	mesh kill
				if( _target.geometry ){	_target.geometry.dispose();	};
				if( _target.material ){	_target.material.dispose();	};
				if( _target.texture ){	_target.texture.dispose();	};
				if( _target.geometry ){	_target.geometry.dispose();	};

				_target.parent.remove( _target );
				_target = null;
			}
			
			_t.camera = null;
		}
	}
}