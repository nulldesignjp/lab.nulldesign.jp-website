/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />
var scene05 = (function () {
    function scene05(_camera) {
        console.log('scene ' + '%cscene05', 'color: #990000;font: bold 12px sans-serif;');
        var _t = this;
        _t.scene = new THREE.Scene();
        _t.scene.fog = new THREE.Fog(0x000000, 800, 1600);
        _t.container = new THREE.Group();
        _t.scene.add(_t.container);
        _t.camera = _camera;
        var _p0 = new THREE.PointLight(0x4fe3e3, 2.0, 800);
        _t.container.add(_p0);
        _p0.position.set(-160, -40, 400);
        var _p1 = new THREE.PointLight(0xf659f1, 2.0, 800);
        _t.container.add(_p1);
        _p1.position.set(160, 40, 400);
        for (var i = 0; i < 720; i++) {
            var _size = Math.floor(Math.random() * 40) + 40;
            var geometry = new THREE.PlaneGeometry(_size, _size, 1, 1);
            var material = new THREE.MeshLambertMaterial({ color: 0xFFFFFF, side: THREE.DoubleSide });
            var _mesh = new THREE.Mesh(geometry, material);
            _t.container.add(_mesh);
            var _rad = rnd() * Math.PI;
            var _radius = Math.random() * 240 + 160;
            var _x = Math.cos(_rad) * _radius;
            var _y = Math.sin(_rad) * _radius;
            var _z = rnd() * 2600;
            _mesh.position.set(_x, _y, _z);
            _mesh.rotation.z = _rad;
        }
        //	+-1.0
        function rnd() {
            return Math.random() * 2 - 1;
        }
    }
    scene05.prototype.update = function () {
        var _t = this;
        _t.container.rotation.z += 0.001;
    };
    scene05.prototype.interactive = function (_type, _data) {
    };
    scene05.prototype.dispose = function () {
        var _t = this;
        kill(_t.scene);
        function kill(e) {
            var len = e.children.length;
            while (len) {
                len--;
                var _target = e.children[len];
                //	再起kill
                if (_target.length) {
                    kill(_target);
                }
                //	mesh kill
                if (_target.geometry) {
                    _target.geometry.dispose();
                }
                ;
                if (_target.material) {
                    _target.material.dispose();
                }
                ;
                if (_target.texture) {
                    _target.texture.dispose();
                }
                ;
                if (_target.geometry) {
                    _target.geometry.dispose();
                }
                ;
                _target.parent.remove(_target);
                _target = null;
            }
            _t.camera = null;
        }
    };
    return scene05;
})();
