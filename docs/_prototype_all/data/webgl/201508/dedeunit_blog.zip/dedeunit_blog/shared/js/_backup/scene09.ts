/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />

class scene09
{
	public scene:any;

	private camera:any;
	private container:any;
	private uniforms:any;

	constructor( _camera )
	{
		console.log( 'scene ' + '%cscene09',  'color: #990000;font: bold 12px sans-serif;' );

		var _t = this;
		_t.scene = new THREE.Scene();
		_t.scene.fog = new THREE.Fog( 0x000000, 800, 1600 );

		_t.container = new THREE.Group();
		_t.scene.add( _t.container );

		_t.camera = _camera;

		_t.uniforms = {
			time: { 'type': 'f', 'value': 0.0 },
			resolution: { 'type': 'v2', 'value': new THREE.Vector2() },
			mouse: { 'type': 'v2', 'value': new THREE.Vector2() }
		};
		_t.uniforms.time.value = 0.0;
		_t.uniforms.resolution.value.x = window.innerWidth;
		_t.uniforms.resolution.value.y = window.innerHeight;
		_t.uniforms.mouse.value.x = 0;
		_t.uniforms.mouse.value.y = 0;

		var geometry = new THREE.PlaneGeometry( 100, 100, 1 );

		var material = new THREE.ShaderMaterial( {
			uniforms:       _t.uniforms,
			vertexShader:   document.getElementById( 'vertexshader' ).textContent,
			fragmentShader: document.getElementById( 'fragmentshader' ).textContent,
			blending:       THREE.AdditiveBlending,
			depthTest:      false,
			transparent:    true
		});
		var mesh = new THREE.Mesh( geometry, material );
		mesh.scale.set( 10, 3, 0 );
		_t.container.add( mesh );

		//	+-1.0
		function rnd()
		{
			return Math.random()*2-1;
		}
	}

	public update()
	{
		var _t = this;

		_t.uniforms.time.value += 0.05;
	}

	public interactive( _type, _data )
	{
	}

	public dispose()
	{
		var _t = this;
		kill( _t.scene );

		function kill( e )
		{
			var len = e.children.length;
			while( len )
			{
				len --;
				var _target = e.children[len];
				
				//	再起kill
				if( _target.length )
				{
					kill( _target );
				}

				//	mesh kill
				if( _target.geometry ){	_target.geometry.dispose();	};
				if( _target.material ){	_target.material.dispose();	};
				if( _target.texture ){	_target.texture.dispose();	};
				if( _target.geometry ){	_target.geometry.dispose();	};

				_target.parent.remove( _target );
				_target = null;
			}
			
			_t.camera = null;
		}
	}
}