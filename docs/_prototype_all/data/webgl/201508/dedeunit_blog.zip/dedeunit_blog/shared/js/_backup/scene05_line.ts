/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />
/// <reference path="./SimplexNoise.ts" />

class scene05
{
	public scene:any;

	private camera:any;
	private container:any;

	private cubeLine:any;

	constructor( _camera, _focus, _sky )
	{
		console.log( 'scene ' + '%cscene05',  'color: #990000;font: bold 12px sans-serif;' );

		var _t = this;
		_t.scene = new THREE.Scene();
		_t.scene.fog = new THREE.Fog( 0x000000, 800, 1600 );

		_t.container = new THREE.Group();
		_t.scene.add( _t.container );

		_t.camera = _camera;


		var _geometry = new THREE.Geometry();
		var _grid = 300;
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 1.5, _grid * 1.5	)	);

		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 1.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 1.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 0.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 0.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 0.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 0.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 1.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 1.5, _grid * 0.5	)	);

		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 1.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 1.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 0.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 0.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 0.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 0.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 1.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 1.5, - _grid * 0.5	)	);

		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 1.5, - _grid * 1.5	)	);


		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, - _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, - _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 1.5, _grid * 1.5	)	);

		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 1.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 1.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, _grid * 1.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, - _grid * 1.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, _grid * 1.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, - _grid * 1.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 1.5, _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 1.5, _grid * 0.5	)	);

		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 1.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 1.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, _grid * 1.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, - _grid * 1.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, _grid * 1.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, - _grid * 1.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 1.5, - _grid * 0.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 1.5, - _grid * 0.5	)	);

		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, - _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, - _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 1.5, - _grid * 1.5	)	);


		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 1.5, - _grid * 1.5, - _grid * 1.5	)	);

		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, - _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, - _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, - _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	- _grid * 0.5, - _grid * 1.5, - _grid * 1.5	)	);

		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, - _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, - _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, - _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 0.5, - _grid * 1.5, - _grid * 1.5	)	);

		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 1.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 0.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 0.5, - _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 1.5, _grid * 1.5	)	);
		_geometry.vertices.push(	new THREE.Vector3(	_grid * 1.5, - _grid * 1.5, - _grid * 1.5	)	);


		var _material = new THREE.LineBasicMaterial({
			blending:       THREE.AdditiveBlending,
			transparent: true,
			opacity: 0.5
		});
		_t.cubeLine = new THREE.Line( _geometry, _material, THREE.LinePieces );
		_t.container.add( _t.cubeLine );

		//	+-1.0
		function rnd()
		{
			return Math.random()*2-1;
		}
	}

	public update()
	{
		var _t = this;

		_t.cubeLine.rotation.x += 0.01;
		_t.cubeLine.rotation.y += 0.01;
	}

	public interactive( _type, _data )
	{
		var _t = this;
		if( _type == 'kinect' )
		{
			var _isLeft = _data.gestureData.IsSwipeLeft;
			var _isRight = _data.gestureData.IsSwipeRight;
			var _isCharge = _data.gestureData.IsCharge;

			if( _isLeft )
			{
			}
			if( _isRight )
			{
			}
			if( _isCharge )
			{
			}
		}
	}

	public effects()
	{
		
	}

	public dispose()
	{
		var _t = this;
		kill( _t.scene );

		function kill( e )
		{
			var len = e.children.length;
			while( len )
			{
				len --;
				var _target = e.children[len];
				
				//	再起kill
				if( _target.length )
				{
					kill( _target );
				}

				//	mesh kill
				if( _target.geometry ){	_target.geometry.dispose();	};
				if( _target.material ){	_target.material.dispose();	};
				if( _target.texture ){	_target.texture.dispose();	};
				if( _target.geometry ){	_target.geometry.dispose();	};

				_target.parent.remove( _target );
				_target = null;
			}
			
			_t.camera = null;
		}
	}
}