/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />
/// <reference path="./SimplexNoise.ts" />

class scene04
{
	public scene:any;

	private camera:any;
	private focus:any;
	private sky:any;
	private container:any;
	private lineNums:number;
	private lineLenght:number;
	private lineList:any[];
	private sn:any;
	private speed:number;
	private scale:number;
	private frection:number;
	private particleAccell:number;
	private r:number;
	private g:number;
	private b:number;

	constructor( _camera, _focus, _sky )
	{
		console.log( 'scene ' + '%cscene04',  'color: #990000;font: bold 12px sans-serif;' );

		var _t = this;
		_t.scene = new THREE.Scene();
		_t.scene.fog = new THREE.Fog( 0x000000, 800, 1600 );

		_t.container = new THREE.Group();
		_t.scene.add( _t.container );

		_t.camera = _camera;
		_t.focus = _focus;
		_t.sky = _sky;

		//	INIT
		_t.lineNums = 512;
		_t.lineLenght = 48;
		_t.lineList = [];
		_t.sn = new SimplexNoise();
		_t.speed = 0.52;
		_t.scale = 1.6;
		_t.frection = 0.96;
		_t.particleAccell = 0.01;
		_t.r = Math.random();
		_t.g = Math.random();
		_t.b = Math.random();

		var _material = new THREE.LineBasicMaterial({
			linewidth:	3,
			color:	new THREE.Color(_t.r,_t.g,_t.b),
			transparent:	true,
			opacity:	0.6,
			blending:       THREE.AdditiveBlending,
			depthTest:      false
		});

		for( var i = 0; i < _t.lineNums; i++ )
		{
			var _geometry = new THREE.Geometry();
			for( var j = 0; j < _t.lineLenght; j++ )
			{
				_geometry.vertices[j] = new THREE.Vector3(0,0,0);
			}

			var _mesh = new THREE.Line( _geometry, _material );
			_t.container.add( _mesh );

			var _vx = rnd()*10.0;
			var _vy = rnd()*10.0;
			var _vz = rnd()*10.0;

			_t.lineList.push({
				mesh:_mesh,
				geometry:_geometry,
				vx: _vx,
				vy: _vy,
				vz: _vz
			});
		}

		//	+-1.0
		function rnd()
		{
			return Math.random()*2-1;
		}
	}

	public update()
	{
		var _t = this;
		_t.container.rotation.x += 0.001;
		_t.container.rotation.y += 0.001;
		_t.container.rotation.z += 0.001;

		//	LINE
		var _size = 1000.0;
		var _hsize = _size * 0.5;

		var len = _t.lineList.length;
		while( len )
		{
			len--;
			var _obj = _t.lineList[len];
			var _vertices = _obj.geometry.vertices;
			var _px = _vertices[0].x;
			var _py = _vertices[0].y;
			var _pz = _vertices[0].z;

			var len0 = _vertices.length;
			for( var i = 0; i < len0; i++ )
			{
				var __px = _vertices[i].x;
				var __py = _vertices[i].y;
				var __pz = _vertices[i].z;

				_vertices[i].x = _px;
				_vertices[i].y = _py;
				_vertices[i].z = _pz;

				_px = __px;
				_py = __py;
				_pz = __pz;
			}
			_vertices[0].x += _obj.vx;
			_vertices[0].y += _obj.vy;
			_vertices[0].z += _obj.vz;

			_obj.vx += _t.sn.noise( ( _vertices[0].z + _hsize ) / _size * _t.scale, ( _vertices[0].y + _hsize ) / _size * _t.scale ) * _t.speed;
			_obj.vy += _t.sn.noise( ( _vertices[0].x + _hsize ) / _size * _t.scale, ( _vertices[0].z + _hsize ) / _size * _t.scale ) * _t.speed;
			_obj.vz += _t.sn.noise( ( _vertices[0].y + _hsize ) / _size * _t.scale, ( _vertices[0].x + _hsize ) / _size * _t.scale ) * _t.speed;

			//	air frection
			_obj.vx *= _t.frection;
			_obj.vy *= _t.frection;
			_obj.vz *= _t.frection;

			//	pseudo grav
			_vertices[0].x += ( 0 - _vertices[0].x ) * _t.particleAccell;
			_vertices[0].y += ( 0 - _vertices[0].y ) * _t.particleAccell;
			_vertices[0].z += ( 0 - _vertices[0].z ) * _t.particleAccell;

			//
			if( _vertices[0].x < -_hsize )
			{
				_vertices[0].x = -_hsize;
				_obj.vx *= - ( Math.random() * .2 + .9 );

			} else if( _vertices[0].x > _hsize )
			{
				_vertices[0].x = _hsize;
				_obj.vx *= - ( Math.random() * .2 + .9 );
			}
			if( _vertices[0].y < -_hsize )
			{
				_vertices[0].y = -_hsize;
				_obj.vy *= - ( Math.random() * .2 + .9 );
			} else if( _vertices[0].y > _hsize )
			{
				_vertices[0].y = _hsize;
				_obj.vy *= - ( Math.random() * .2 + .9 );
			}
			if( _vertices[0].z < -_hsize )
			{
				_vertices[0].z = -_hsize;
				_obj.vz *= - ( Math.random() * .2 + .9 );
			} else if( _vertices[0].z > _hsize )
			{
				_vertices[0].z = _hsize;
				_obj.vz *= - ( Math.random() * .2 + .9 );
			}
			_obj.geometry.verticesNeedUpdate = true;
		}
	}

	public interactive( _type, _data )
	{
		var _t = this;
		if( _type == 'kinect' )
		{
			var _isLeft = _data.gestureData.IsSwipeLeft;
			var _isRight = _data.gestureData.IsSwipeRight;
			var _isCharge = _data.gestureData.IsCharge;

			if( _isLeft )
			{
			}
			if( _isRight )
			{
			}
			if( _isCharge )
			{
			}
		}
	}

	public effects()
	{
		
	}

	public dispose()
	{
		var _t = this;
		kill( _t.scene );

		function kill( e )
		{
			var len = e.children.length;
			while( len )
			{
				len --;
				var _target = e.children[len];
				
				//	再起kill
				if( _target.length )
				{
					kill( _target );
				}

				//	mesh kill
				if( _target.geometry ){	_target.geometry.dispose();	};
				if( _target.material ){	_target.material.dispose();	};
				if( _target.texture ){	_target.texture.dispose();	};
				if( _target.geometry ){	_target.geometry.dispose();	};

				_target.parent.remove( _target );
				_target = null;
			}
			
			_t.camera = null;
			_t.focus = null;
			_t.sky = null;
		}
	}
}