/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />

class scene03
{
	public scene:any;

	private camera:any;
	private container:any;

	constructor( _camera )
	{
		console.log( 'scene ' + '%cscene03',  'color: #990000;font: bold 12px sans-serif;' );

		var _t = this;
		_t.scene = new THREE.Scene();
		_t.scene.fog = new THREE.Fog( 0x000000, 800, 1600 );

		_t.container = new THREE.Group();
		_t.scene.add( _t.container );

		_t.camera = _camera;

		var geometry = new THREE.TextGeometry( 'DE DE MOUE x HACKist', {size: 64,height:16});
		geometry.computeBoundingBox();
		geometry.computeVertexNormals()
		var material = new THREE.MeshBasicMaterial();
		var _mesh = new THREE.Mesh( geometry, material );
		_t.container.add( _mesh );

		var geometry = new THREE.TextGeometry( 'DE DE MOUE x HACKist', {size: 64,height:16});
		geometry.computeBoundingBox();
		geometry.computeVertexNormals()
		var material = new THREE.MeshBasicMaterial({wireframe:true});
		var _mesh = new THREE.Mesh( geometry, material );
		_mesh.position.y = - 64;
		_t.container.add( _mesh );

		var geometry = new THREE.TextGeometry( '2015.0723 in UNIT Daikanyama.', {size: 32,height:16});
		geometry.computeBoundingBox();
		geometry.computeVertexNormals()
		var material = new THREE.MeshBasicMaterial();
		var _mesh = new THREE.Mesh( geometry, material );
		_mesh.position.y = - 112;
		_t.container.add( _mesh );

	
		var geometry = new THREE.TextGeometry( 'Hiroshi KOI FCL / nulldesign.jp', {size: 32,height:16});
		geometry.computeBoundingBox();
		geometry.computeVertexNormals()
		var material = new THREE.MeshBasicMaterial();
		var _mesh = new THREE.Mesh( geometry, material );
		_mesh.position.y = - 144;
		_t.container.add( _mesh );

		//	+-1.0
		function rnd()
		{
			return Math.random()*2-1;
		}
	}

	public update()
	{
		var _t = this;
		_t.container.rotation.x += 0.0002;
		_t.container.rotation.y += 0.0015;
	}

	public interactive( _type, _data )
	{
	}
	
	public dispose()
	{
		var _t = this;
		kill( _t.scene );

		function kill( e )
		{
			var len = e.children.length;
			while( len )
			{
				len --;
				var _target = e.children[len];
				
				//	再起kill
				if( _target.length )
				{
					kill( _target );
				}

				//	mesh kill
				if( _target.geometry ){	_target.geometry.dispose();	};
				if( _target.material ){	_target.material.dispose();	};
				if( _target.texture ){	_target.texture.dispose();	};
				if( _target.geometry ){	_target.geometry.dispose();	};

				_target.parent.remove( _target );
				_target = null;
			}
			
			_t.camera = null;
		}
	}
}