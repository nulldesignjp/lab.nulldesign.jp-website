/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />
var scene04 = (function () {
    function scene04(_camera) {
        console.log('scene ' + '%cscene04', 'color: #990000;font: bold 12px sans-serif;');
        var _t = this;
        _t.scene = new THREE.Scene();
        _t.scene.fog = new THREE.Fog(0x000000, 800, 1600);
        _t.container = new THREE.Group();
        _t.scene.add(_t.container);
        _t.camera = _camera;
        _t.grid = 40;
        _t.cubeStockList = [];
        _t.cubeViewList = [];
        for (var i = 0; i < 1000; i++) {
            var _geo = new THREE.BoxGeometry(_t.grid - 5, _t.grid - 5, _t.grid - 5, 1, 1, 1);
            var _mat = new THREE.MeshNormalMaterial();
            var _mesh = new THREE.Mesh(_geo, _mat);
            _t.cubeStockList[i] = _mesh;
        }
        //	+-1.0
        function rnd() {
            return Math.random() * 2 - 1;
        }
    }
    scene04.prototype.update = function () {
        var _t = this;
        var len = _t.cubeViewList.length;
        while (len) {
            len--;
            var _mesh = _t.cubeViewList.pop();
            _t.cubeStockList.push(_mesh);
            _t.container.remove(_mesh);
        }
        var _r = Math.floor((Math.sin(Date.now() * 0.005) + 1.0) * 200) + 50;
        _t.drawCircle(0, 0, 0, _r);
        _t.drawCircle(640, 0, 0, _r * 0.5);
        _t.drawCircle(-640, 0, 0, _r * 2.0);
    };
    scene04.prototype.interactive = function (_type, _data) {
    };
    scene04.prototype.drawCircle = function (_centerX, _centerY, _offsetZ, radius) {
        radius = radius == undefined ? 100 : radius;
        var _t = this;
        var _w = window.innerWidth;
        var _h = window.innerHeight;
        var d = 1 - radius;
        var dH = 3;
        var dD = 5 - 2 * radius;
        var cy = radius;
        var _mx = Math.floor(_centerX / _t.grid) * _t.grid;
        var _my = Math.floor(_centerY / _t.grid) * _t.grid;
        var _stock = [];
        for (var cx = 0; cx <= cy; cx++) {
            if (d < 0) {
                d += dH;
                dH += 2;
                dD += 2;
            }
            else {
                d += dD;
                dH += 2;
                dD += 4;
                --cy;
            }
            var _cx = Math.floor(cx / _t.grid) * _t.grid;
            var _cy = Math.floor(cy / _t.grid) * _t.grid;
            var _pos = [
                [_cy + _mx, _cx + _my],
                [_cx + _mx, _cy + _my],
                [-_cy + _mx, _cx + _my],
                [-_cx + _mx, _cy + _my],
                [-_cy + _mx, -_cx + _my],
                [-_cx + _mx, -_cy + _my],
                [_cy + _mx, -_cx + _my],
                [_cx + _mx, -_cy + _my]
            ];
            for (var i = 0; i < _pos.length; i++) {
                var _flag = true;
                for (var j = 0; j < _stock.length; j++) {
                    if (_stock[j][0] == _pos[i][0] && _stock[j][1] == _pos[i][1]) {
                        _flag = false;
                        break;
                    }
                }
                if (_t.cubeStockList.length && _flag) {
                    var _mesh = _t.cubeStockList.pop();
                    _t.cubeViewList.push(_mesh);
                    _t.container.add(_mesh);
                    _mesh.position.set(_pos[i][0], _pos[i][1], _offsetZ);
                    _stock.push([_pos[i][0], _pos[i][1]]);
                }
            }
        }
    };
    scene04.prototype.dispose = function () {
        var _t = this;
        kill(_t.scene);
        function kill(e) {
            var len = e.children.length;
            while (len) {
                len--;
                var _target = e.children[len];
                //	再起kill
                if (_target.length) {
                    kill(_target);
                }
                //	mesh kill
                if (_target.geometry) {
                    _target.geometry.dispose();
                }
                ;
                if (_target.material) {
                    _target.material.dispose();
                }
                ;
                if (_target.texture) {
                    _target.texture.dispose();
                }
                ;
                if (_target.geometry) {
                    _target.geometry.dispose();
                }
                ;
                _target.parent.remove(_target);
                _target = null;
            }
            _t.camera = null;
        }
    };
    return scene04;
})();
