/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />
var scene06 = (function () {
    function scene06(_camera) {
        this.rotateX = 0;
        this.rotateY = 0;
        this.rotateZ = 0;
        console.log('scene ' + '%cscene06', 'color: #990000;font: bold 12px sans-serif;');
        var _t = this;
        _t.scene = new THREE.Scene();
        _t.scene.fog = new THREE.Fog(0x000000, 800, 1600);
        _t.container = new THREE.Group();
        _t.scene.add(_t.container);
        _t.camera = _camera;
        var geometry = new THREE.Geometry();
        for (var i = 0; i < 256; i++) {
            geometry.vertices[i] = new THREE.Vector3(rnd() * 256, rnd() * 256, rnd() * 256);
        }
        var material = new THREE.PointCloudMaterial({
            size: 1900.0,
            //color: 0xf659f1,
            color: 0x4fe3e3,
            transparent: true,
            opacity: 0.6,
            blending: THREE.AdditiveBlending,
            depthTest: false,
            map: THREE.ImageUtils.loadTexture('./shared/img/spark1.png')
        });
        // var _shaderMaterial = new THREE.ShaderMaterial( {
        // 	uniforms:       WorldVJ.uniforms,
        // 	vertexShader:   document.getElementById( 'vertexshader' ).textContent,
        // 	fragmentShader: document.getElementById( 'fragmentshader' ).textContent,
        // 	blending:       THREE.AdditiveBlending,
        // 	depthTest:      false,
        // 	transparent:    true,
        // 	map: WorldVJ.unirorms.backbuffer.value
        // });
        var mesh = new THREE.PointCloud(geometry, material);
        _t.container.add(mesh);
        //	+-1.0
        function rnd() {
            return Math.random() * 2 - 1;
        }
    }
    scene06.prototype.update = function () {
        var _t = this;
        _t.container.rotation.y += 0.005;
        _t.container.rotation.x += _t.rotateX;
        _t.container.rotation.y += _t.rotateY;
        _t.container.rotation.z += _t.rotateZ;
    };
    scene06.prototype.interactive = function (_type, _data) {
        if (_type == 'accell') {
            var _t = this;
            _t.rotateX = _data.x / 180 * Math.PI;
            _t.rotateY = _data.y / 180 * Math.PI;
            _t.rotateZ = _data.z / 180 * Math.PI;
        }
    };
    scene06.prototype.dispose = function () {
        var _t = this;
        kill(_t.scene);
        function kill(e) {
            var len = e.children.length;
            while (len) {
                len--;
                var _target = e.children[len];
                //	再起kill
                if (_target.length) {
                    kill(_target);
                }
                //	mesh kill
                if (_target.geometry) {
                    _target.geometry.dispose();
                }
                ;
                if (_target.material) {
                    _target.material.dispose();
                }
                ;
                if (_target.texture) {
                    _target.texture.dispose();
                }
                ;
                if (_target.geometry) {
                    _target.geometry.dispose();
                }
                ;
                _target.parent.remove(_target);
                _target = null;
            }
            _t.camera = null;
        }
    };
    return scene06;
})();
