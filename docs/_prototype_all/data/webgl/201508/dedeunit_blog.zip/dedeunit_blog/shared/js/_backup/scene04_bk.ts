/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />

class scene04
{
	public scene:any;

	private container:any;
	private intervalKey:any;
	private pList:any;

	constructor()
	{
		console.log( 'scene ' + '%cscene04',  'color: #990000;font: bold 12px sans-serif;' );

		var _t = this;
		_t.scene = new THREE.Scene();
		_t.scene.fog = new THREE.Fog( 0x000000, 800, 1600 );

		_t.container = new THREE.Group();
		_t.scene.add( _t.container );


		_t.intervalKey;
		_t.pList = [];

		createF();
		loop();

		function loop()
		{
			var len0 = _t.pList.length;
			while( len0 )
			{
				len0 --;
				var _p = _t.pList[len0];
				var len = _p.geometry.vertices.length;
				for( var i = 0; i < len; i++ )
				{
					_p.geometry.vertices[i].x += _p.geometry.vector[i].x;
					_p.geometry.vertices[i].y += _p.geometry.vector[i].y;
					_p.geometry.vertices[i].z += _p.geometry.vector[i].z;

					_p.geometry.vector[i].y -= 0.0275;

					_p.geometry.vector[i].x *= 0.98;
					_p.geometry.vector[i].y *= 0.98;
					_p.geometry.vector[i].z *= 0.98;
				}
				_p.geometry.verticesNeedUpdate = true;
				_p.geometry.life ++;

				if( _p.geometry.life / _p.geometry.limit > 0.8 )
				{
					_p.material.opacity = 1.0 - ( _p.geometry.life / _p.geometry.limit - 0.8 ) * 5;
				}

				if( _p.geometry.life > _p.geometry.limit )
				{
					_t.pList.splice( len0, 1 );
					_t.scene.remove( _p );

					_p.geometry.dispose();
					_p.geometry = null;
					_p = null;
				}

			}
			window.requestAnimationFrame(loop);
		}

		function createF()
		{
			clearTimeout( _t.intervalKey );
			if( _t.pList.length < 20 )
			{
				var _p = createFireWork();
				_t.scene.add( _p );
				_p.position.x = rnd() * 1280;
				_p.position.y = rnd() * 100;
				_p.position.z = rnd() * 300;
				_t.pList.push( _p );
			}

			_t.intervalKey = setTimeout( createF, Math.random() * 500 + 50 )
		}

		function createFireWork()
		{
			var _geometry = new THREE.Geometry();

			_geometry.vector = [];

			_geometry.life = 0;
			_geometry.limit = Math.floor( Math.random() * 30 + 50 );

			for( var i = 0; i < 10000; i++ )
			{
				var _rad0 = Math.random() * Math.PI * 2.0;
				var _rad1 = Math.random() * Math.PI * 2.0;

				var _pow = ( Math.random()*.2+.9)*8;

				var _r = Math.cos( _rad0 ) * _pow;
				var _y = Math.sin( _rad0 ) * _pow;
				var _x = Math.cos( _rad1 ) * _r;
				var _z = Math.sin( _rad1 ) * _r;

				_geometry.vertices[i] = new THREE.Vector3( _x, _y, _z );
				_geometry.vector[i] = new THREE.Vector3( _x, _y, _z );
			}

			var _color = new THREE.Color( Math.random(),Math.random(),Math.random());

			var _material = new THREE.PointCloudMaterial({
				size: Math.random() * 8.0 + 2.0,
				//size: Math.random() * 16.0 + 18.0,
				blending:       THREE.AdditiveBlending,
				transparent:true,
				color: _color,
			//map: THREE.ImageUtils.loadTexture( "spark1.png" ),
			//depthTest:      false
			});
			var _particle = new THREE.PointCloud( _geometry, _material );
			return _particle;
		}


		//	+-1.0
		function rnd()
		{
			return Math.random()*2-1;
		}
	}

	public update()
	{
		var _t = this;
		_t.container.rotation.x += 0.0002;
		_t.container.rotation.y += 0.0015;
	}

	public dispose()
	{
		var _t = this;
		clearTimeout( _t.intervalKey );
		kill( _t.scene );
		_t.scene = null;
		
		function kill( e )
		{
			var len = e.children.length;
			while( len -- )
			{
				//	再起kill
				if( e.children[len].length )
				{
					kill( e.children[len] );
				}

				//	mesh kill
				if( e.children[len].geometry ){	e.children[len].geometry.dispose();	};
				e.children[len].parent.remove( e.children[len] );
				e.children[len] = null;

			}
		}
	}
}