/// <reference path="WorldVJ.ts" />
var DEDEMOUSE = (function () {
    function DEDEMOUSE(_container) {
        console.log('%cDE DE MOUSE x HACKist.', 'color: #003366;font: bold 16px sans-serif;', DEDEMOUSE.version);
        this.world = new WorldVJ(_container);
    }
    DEDEMOUSE.version = '2.0.3';
    return DEDEMOUSE;
})();
new DEDEMOUSE(document.getElementById('container'));
setTimeout(function () {
    $('#container').addClass('fadeIn');
}, 1000);
