/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />

class scene00
{
	public scene:any;

	private camera:any;
	private container:any;

	constructor( _camera )
	{
		console.log( 'scene ' + '%cscene00',  'color: #990000;font: bold 12px sans-serif;' );

		var _t = this;
		_t.scene = new THREE.Scene();
		_t.scene.fog = new THREE.Fog( 0x000000, 800	, 1600 );

		_t.container = new THREE.Group();
		_t.scene.add( _t.container );

		_t.camera = _camera;

		var _p0 = new THREE.PointLight( 0x4fe3e3, 2.0, 200 );
		_t.container.add( _p0 );
		_p0.position.set( -80, -20, 300);

		var _p1 = new THREE.PointLight( 0xf659f1, 2.0, 200 );
		_t.container.add( _p1 );
		_p1.position.set( 80, 20, 300);

		var _map = THREE.ImageUtils.loadTexture( "./shared/img/logo_hackist.png", null, function(e){
			var _g = new THREE.PlaneGeometry(512,512,4,4);
			var _m = new THREE.MeshLambertMaterial({map:e,transparent:true,side:THREE.DoubleSide});
			var _mesh = new THREE.Mesh( _g, _m );
			_mesh.position.z = 250;
			_t.container.add( _mesh );
		});
	}

	public update()
	{
		var _t = this;
	}

	public interactive( _type, _data )
	{
	}

	public dispose()
	{
		var _t = this;
		kill( _t.scene );

		function kill( e )
		{
			var len = e.children.length;
			while( len )
			{
				len --;
				var _target = e.children[len];
				
				//	再起kill
				if( _target.length )
				{
					kill( _target );
				}

				//	mesh kill
				if( _target.geometry ){	_target.geometry.dispose();	};
				if( _target.material ){	_target.material.dispose();	};
				if( _target.texture ){	_target.texture.dispose();	};
				if( _target.geometry ){	_target.geometry.dispose();	};

				_target.parent.remove( _target );
				_target = null;
			}
			
			_t.camera = null;
		}
	}
}