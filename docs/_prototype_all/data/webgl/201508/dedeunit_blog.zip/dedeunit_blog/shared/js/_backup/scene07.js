/// <reference path="./jquery/jquery.d.ts" />
/// <reference path="./threejs/three.d.ts" />
var scene07 = (function () {
    function scene07(_camera) {
        console.log('scene ' + '%cscene07', 'color: #990000;font: bold 12px sans-serif;');
        var _t = this;
        _t.scene = new THREE.Scene();
        _t.scene.fog = new THREE.Fog(0x000000, 800, 1600);
        _t.container = new THREE.Group();
        _t.scene.add(_t.container);
        _t.camera = _camera;
        var geometry = new THREE.Geometry();
        for (var i = 0; i < 300; i++) {
            geometry.vertices[i] = new THREE.Vector3(rnd() * 1280, rnd() * 600, rnd() * 900);
        }
        var material = new THREE.PointCloudMaterial({
            size: 100.0,
            color: 0x4fe3e3,
            transparent: true,
            opacity: 0.8,
            blending: THREE.AdditiveBlending,
            depthTest: false,
            map: THREE.ImageUtils.loadTexture('./shared/img/sphere01.png')
        });
        // var _shaderMaterial = new THREE.ShaderMaterial( {
        // 	uniforms:       WorldVJ.uniforms,
        // 	vertexShader:   document.getElementById( 'vertexshader' ).textContent,
        // 	fragmentShader: document.getElementById( 'fragmentshader' ).textContent,
        // 	blending:       THREE.AdditiveBlending,
        // 	depthTest:      false,
        // 	transparent:    true,
        // 	map: WorldVJ.unirorms.backbuffer.value
        // });
        _t.particle = new THREE.PointCloud(geometry, material);
        _t.container.add(_t.particle);
        //	+-1.0
        function rnd() {
            return Math.random() * 2 - 1;
        }
    }
    scene07.prototype.update = function () {
        var _t = this;
        var _vertices = _t.particle.geometry.vertices;
        var len = _vertices.length;
        while (len) {
            len--;
            _vertices[len].y++;
            if (_vertices[len].y > 512) {
                _vertices[len].y = -512;
            }
        }
        _t.particle.geometry.verticesNeedUpdate = true;
    };
    scene07.prototype.interactive = function (_type, _data) {
    };
    scene07.prototype.dispose = function () {
        var _t = this;
        kill(_t.scene);
        function kill(e) {
            var len = e.children.length;
            while (len) {
                len--;
                var _target = e.children[len];
                //	再起kill
                if (_target.length) {
                    kill(_target);
                }
                //	mesh kill
                if (_target.geometry) {
                    _target.geometry.dispose();
                }
                ;
                if (_target.material) {
                    _target.material.dispose();
                }
                ;
                if (_target.texture) {
                    _target.texture.dispose();
                }
                ;
                if (_target.geometry) {
                    _target.geometry.dispose();
                }
                ;
                _target.parent.remove(_target);
                _target = null;
            }
            _t.camera = null;
        }
    };
    return scene07;
})();
