/// <reference path="WorldVJ.ts" />

class DEDEMOUSE
{
	public static version:string = '2.0.3';

	private world:WorldVJ;
	private isDebug:boolean;

	constructor( _container )
	{
		console.log('%cDE DE MOUSE x HACKist.', 'color: #003366;font: bold 16px sans-serif;', DEDEMOUSE.version );
		this.world = new WorldVJ( _container );
	}

}
new DEDEMOUSE( document.getElementById('container') );

setTimeout(function(){
	$('#container').addClass('fadeIn');
}, 1000 );