/*
	randomtypo.ts
*/

class randomtypo{

	static text:string = '_ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
	static fps:number = 60;

	private dom;
	private text:string;
	private intervalKey:number;
	private count:number;
	private delay:number;

	constructor( _dom, _text:string, _delay:number  )
	{
		this.dom = _dom;
		this.text = _text;
		this.intevalKey = 0;
		this.count = 0;
		this.delay = _delay;
	}


	public setText( _text:string )
	{
		this.text = _text;
	}
	public start()
	{
		this._start();
	}

	private _draw()
	{
		var len = this.text.length;
		var _str = '';

		if( len == 0 )
		{
			_str = this.text;
			this._fixed();
			return;
		}

		var _delay = randomtypo.fps * ( this.delay / 1000 );
		var _strCount = Math.floor( ( this.count - _delay ) * 0.25 );
		_strCount = _strCount<0?0:_strCount;

		if( len < _strCount )
		{
			_str = this.text;
			this._fixed();
			return;
		} else {
			_str = this.text.substr( 0, _strCount );

			var len2 = len - _strCount;

			for( var i = 0; i < len2; i++ )
			{
				_str += randomtypo.text.charAt( Math.floor( Math.random() * randomtypo.text.length ) );
			}
		}

		this.dom.text( _str );

		this.count ++;
	}
	private _fixed()
	{
		var _this = this;
		clearInterval( _this.intevalKey );
		_this.count = 0;
	}
	private _start()
	{
		var _this = this;
		clearInterval( _this.intevalKey );
		_this.intevalKey = setInterval( function(){_this._draw()}, 1000 / randomtypo.fps );
	}
	private _restart()
	{
		this.count = 0;
		this._start();
	}
}
