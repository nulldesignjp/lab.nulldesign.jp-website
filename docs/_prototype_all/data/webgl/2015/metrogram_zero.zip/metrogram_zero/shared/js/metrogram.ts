/*
	metrogram
	typescript training
*/

/// <reference path="/typescript/DefinitelyTyped-master/jquery/jquery.d.ts" />
/// <reference path="/typescript/DefinitelyTyped-master/threejs/three.d.ts" />
/// <reference path="./world3d.ts" />
/// <reference path="./SplineCurve.ts" />

module metrogram{
	var _schdule:Object[] = _schdule||[];
	var _stations:Object[] = [];
	var _clist:Object[] = [];
	
	var _aveX:number = 139.752799;
	var _aveY:number = 35.685175;

	var _scale:number = 12000;
	var _zoom:number = _scale / 12000;

	export class main
	{
		public camera	:	THREE.PerspectiveCamera;
		public scene	:	THREE.Scene;
		public focus	:	THREE.Vector3;

		constructor( _xml, _dom )
		{
			this._loadXML( _xml, _dom );
		}

		private _loadXML( _xml, _dom )
		{
			var _this = this;
			$.ajax({
				url: _xml,
				type: 'GET',
				dataType: 'XML',
				success: function( _xml )
				{
					_this._init( _xml, _dom );
				}
			});
		}

		private _init( _xml, _dom )
		{
			var _plist = {};
			$( _xml ).find('line').each(function(){
				var _lineName = $( this ).attr('id');
				var _color = $( this ).attr('color');
				var _rlist = [];
				$( this ).find('item').each(function(){
					var _x = parseFloat( $( this ).find('location longitude').eq(0).text() );
					var _y = parseFloat( $( this ).find('location latitude').eq(0).text() );

					var _data:Object = {};
					_data['name'] = $( this ).find('name').eq(0).text();
					_data['x'] = _x;
					_data['y'] = _y;

					_clist.push( _data );
				});
			});

			this._init3d( _dom );
		}

		private _init3d( _dom )
		{
			var _t = new metrogram.engine( _dom );

			this.camera = _t.camera;
			this.scene = _t.scene;
			this.focus = _t.focus;

			//	MeshPhongMaterial
			var geometry = new THREE.PlaneGeometry(4000,4000,20,20)
			var material = new THREE.MeshLambertMaterial({color:0xCCCCCC,shading:THREE.NoShading});
			var mesh = new THREE.Mesh( geometry, material );
			this.scene.add( mesh );
			mesh.rotation.x = Math.PI * - 0.5;

			for( var i = 0; i < geometry.vertices.length; i++ )
			{
				geometry.vertices[i].z = - Math.random() * 100 - 50;
			}

			geometry.verticesNeedUpdate = true;

			//
			var _g = new THREE.SphereGeometry(20,4,2);
			var _m = new THREE.MeshLambertMaterial({shading:THREE.NoShading});
			var _me = new THREE.Mesh( _g, _m );
			this.scene.add( _me );

			this.scene.add( new THREE.AmbientLight( 0x333333 ) );
			var _dl = new THREE.PointLight( 0xFFFFFF, 2, 300 );
			_dl.position.set( 0, 100, 0 )
			this.scene.add( _dl );




			var len:number = _clist.length;
			for( var i = 0; i < len; i++ )
			{
				var _data = _clist[i];

				var _g = new THREE.SphereGeometry(10,4,2);
				var _m = new THREE.MeshLambertMaterial({shading:THREE.NoShading});
				var _me = new THREE.Mesh( _g, _m );
				_t.scene.add( _me );

				var _x:number = ( _data['x'] - _aveX ) * _scale;
				var _z:number = ( _data['y'] - _aveY ) * _scale;
				_me.position.set( _x, 0, _z );
			}
		}
	}

	export class engine
	{
		private _world:world3d.main;

		public camera	:	THREE.PerspectiveCamera;
		public scene	:	THREE.Scene;
		public focus	:	THREE.Vector3;

		constructor( _dom )
		{
			var _this = this;
			this._world = new world3d.main( _dom );
			this._world.engine = function(){	_this.engine()	};

			this.camera = this._world.camera;
			this.scene = this._world.scene;
			this.focus = this._world.focus;
		}

		public engine()
		{
			var _rad:number = Date.now() * 0.0001;
			var _x:number = Math.cos( _rad ) * 200;
			var _z:number = Math.sin( _rad ) * 200;
			//this._world.focus.x = _x;
			//this._world.focus.z = _z;
			this._world.camera.position.set( _x, 1000, _z );
		}
	}
}
//	
var _xml = './shared/xml/stationlist.xml';
var _dom = document.getElementById('siteBody');
new metrogram.main( _xml, _dom );