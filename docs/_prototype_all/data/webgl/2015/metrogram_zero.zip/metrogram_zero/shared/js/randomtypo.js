/*
    randomtypo.ts
*/
var randomtypo = (function () {
    function randomtypo(_dom, _text, _delay) {
        this.dom = _dom;
        this.text = _text;
        this.intevalKey = 0;
        this.count = 0;
        this.delay = _delay;
    }
    randomtypo.prototype.setText = function (_text) {
        this.text = _text;
    };
    randomtypo.prototype.start = function () {
        this._start();
    };
    randomtypo.prototype._draw = function () {
        var len = this.text.length;
        var _str = '';
        if (len == 0) {
            _str = this.text;
            this._fixed();
            return;
        }
        var _delay = randomtypo.fps * (this.delay / 1000);
        var _strCount = Math.floor((this.count - _delay) * 0.25);
        _strCount = _strCount < 0 ? 0 : _strCount;
        if (len < _strCount) {
            _str = this.text;
            this._fixed();
            return;
        }
        else {
            _str = this.text.substr(0, _strCount);
            var len2 = len - _strCount;
            for (var i = 0; i < len2; i++) {
                _str += randomtypo.text.charAt(Math.floor(Math.random() * randomtypo.text.length));
            }
        }
        this.dom.text(_str);
        this.count++;
    };
    randomtypo.prototype._fixed = function () {
        var _this = this;
        clearInterval(_this.intevalKey);
        _this.count = 0;
    };
    randomtypo.prototype._start = function () {
        var _this = this;
        clearInterval(_this.intevalKey);
        _this.intevalKey = setInterval(function () {
            _this._draw();
        }, 1000 / randomtypo.fps);
    };
    randomtypo.prototype._restart = function () {
        this.count = 0;
        this._start();
    };
    randomtypo.text = '_ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    randomtypo.fps = 60;
    return randomtypo;
})();
